<?php

echo view('layout/v_header');
echo view('layout/v_nav');
echo view('layout/v_content');
echo view('layout/v_footer');
