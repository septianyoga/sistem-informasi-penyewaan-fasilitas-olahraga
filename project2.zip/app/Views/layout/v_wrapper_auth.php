<?php

echo view('layout/v_header_auth');
echo view('layout/v_content');
echo view('layout/v_footer_auth');
