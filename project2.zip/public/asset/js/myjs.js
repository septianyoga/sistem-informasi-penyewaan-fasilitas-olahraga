function alerttt() {
    Swal.fire('Any fool can use a computer')
    alert('tes')
}